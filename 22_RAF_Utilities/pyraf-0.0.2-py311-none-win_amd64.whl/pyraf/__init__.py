import os
selfpath = os.path.dirname(os.path.realpath(__file__))
os.environ['PYRAF_MODULE_PATH'] = selfpath

from .pyraf import Raf
pyraf.selfpath = selfpath

from .__pydyn__ import Dyn

